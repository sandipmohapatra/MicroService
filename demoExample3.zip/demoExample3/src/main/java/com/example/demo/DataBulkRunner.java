package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "my.app")
public class DataBulkRunner implements CommandLineRunner {
	
	private int id;
	private String title;
	private double version;

	@Override
	public void run(String... args) throws Exception {
		System.out.println("FROM DATA BULK RUNNER");
		System.out.println(this);
	}

	//Source Menu > Generate getters and setters > SelectAll >OK
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	//Source Menu > Generate toString  >OK
	public String toString() {
		return "DataBulkRunner [id=" + id + ", title=" + title + ", version=" + version + "]";
	}

}