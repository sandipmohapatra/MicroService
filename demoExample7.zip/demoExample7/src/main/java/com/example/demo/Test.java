package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.Employee;
@Component	
public class Test implements CommandLineRunner
{
@Autowired
	Employee emp=new Employee();

@Override
public void run(String... args) throws Exception {
	emp.setEmpId(101);
	emp.setEmpName("sandip");
	emp.setEmpSal(25000.45);
	System.out.println(emp.getEmpId());
	System.out.println(emp.getEmpName());
	System.out.println(emp.getEmpSal());
	System.out.println(emp);
	System.out.println(emp.getAdd());
}
}

