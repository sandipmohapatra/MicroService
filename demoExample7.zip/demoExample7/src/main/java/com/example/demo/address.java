package com.example.demo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/*@Data : This is a combination of multiple annotations
@Date = Getter + Setter + RequiredArgsConstructor + ToString + EqualsAndHashCode*/
import lombok.Data;

@Data
@Component
public class address {
	@Value("10")//direct static value
	private Integer roadno;
	@Value("${app.city}")//read from application.properties
	private String city;
	@Value("Karnataka")
	private String state;
}
