/* 1.@Setter and  @Getter
  These annotations are used to generate set/get methods for our variables in class

2. @ToString 
  This annotation generate toString() method [Override toString() from Object class]

3. @EqualsAndHashCode
  This annotation generate equals() with hashCode() [Override equals() and hashCode()]
  *) To compare same class different objects data, override equals and hashcode methods.

4. @NoArgsConstructor
   This annotation generate default constructor

5. @AllArgsConstructor
   This annotation generate all parametrized constructor.*/

package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Component("emp")//It says to container to create object.
public class Employee {
	private Integer empId;
	private String empName;
	private Double empSal;
	@Autowired //Link two different objects.classes must be connected using HAS-A relation.
	private address add;
}