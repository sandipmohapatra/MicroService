package com.sandip;

import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestParam;  
  
@Controller  
public class HelloController1 {  
  
    @RequestMapping("/register")  
    public String display(@RequestParam("name") String name,@RequestParam("pass") String pass,Model m)  
    {  
        //read the provided form data  
              if(name.equals("sandip")&&pass.equals("1234") ) 
        {  
            String msg="Hello "+ name;  
            //add a message to the model  
            m.addAttribute("message", msg);  
            return "viewpage";  
        }  
        else  
        {  
            String msg="Sorry "+ name+". You entered an incorrect password enter again correctly";  
            m.addAttribute("message", msg);  
            return "final";  
        }     
    }  
}  