package com.example.demo;
import com.example.demo.Employee1;
public class Test2 
{
	public static void main(String[] args) {
Employee1 emp=new Employee1();
emp.setEmpId(102);
emp.setEmpName("Kiran");
emp.setEmpSal(35000.45);
System.out.println(emp.getEmpId());
System.out.println(emp.getEmpName());
System.out.println(emp.getEmpSal());
System.out.println(emp);
}
}
