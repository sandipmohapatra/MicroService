package com.example.demo;
/*@Data : This is a combination of multiple annotations
@Date = Getter + Setter + RequiredArgsConstructor + ToString + EqualsAndHashCode*/
import lombok.Data;

@Data
public class Employee1 {
	private Integer empId;
	private String empName;
	private Double empSal;
}
