package com.example.demo;
import com.example.demo.Employee;
public class Test 
{
	public static void main(String[] args) {
		
	
Employee emp=new Employee();
emp.setEmpId(101);
emp.setEmpName("sandip");
emp.setEmpSal(25000.45);
System.out.println(emp.getEmpId());
System.out.println(emp.getEmpName());
System.out.println(emp.getEmpSal());
System.out.println(emp);
}
}
