package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "my.app")
public class YamlTestBulkLoad implements CommandLineRunner {

	private int id;
	private String code;
	private double ver;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("from bulk");
		System.out.println(this);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public double getVer() {
		return ver;
	}

	public void setVer(double ver) {
		this.ver = ver;
	}

	@Override
	public String toString() {
		return "YamlTestBulkLoad [id=" + id + ", code=" + code + ", ver=" + ver + "]";
	}

	
}