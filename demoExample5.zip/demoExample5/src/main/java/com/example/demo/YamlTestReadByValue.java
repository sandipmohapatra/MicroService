package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class YamlTestReadByValue implements CommandLineRunner {
	@Value("${my.app.id}")
	private int id;
	
	@Value("${my.app.code}")
	private String code;
	
	@Value("${my.app.ver}")
	private double version;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println(this);
	}

	@Override
	public String toString() {
		return "YamlTestReadByValue [id=" + id + ", code=" + code + ", version=" + version + "]";
	}

}