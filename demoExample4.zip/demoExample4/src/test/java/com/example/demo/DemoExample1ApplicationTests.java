package com.example.demo;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoExample1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
