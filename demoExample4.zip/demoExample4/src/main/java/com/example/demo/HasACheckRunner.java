package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.example.demo.Brand;

@Component
@ConfigurationProperties(prefix = "my.app")
public class HasACheckRunner implements CommandLineRunner {

	private Brand bob; //HAS-A Relation
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println(this);
	}

	//alt+shift+S > R > selectAll > OK
	public Brand getBob() {
		return bob;
	}
	public void setBob(Brand bob) {
		this.bob = bob;
	}
	//alt+shift+S > S > OK
	@Override
	public String toString() {
		return "HasACheckRunner [bob=" + bob + "]";
	}
	
}